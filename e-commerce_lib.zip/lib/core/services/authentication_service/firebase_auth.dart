import 'package:firebase_auth/firebase_auth.dart';

class AuthService
{
 static Future<UserCredential> createUser({required String email,required String password})async {
    final firebase = FirebaseAuth.instance;
    final userCredentials = await firebase.createUserWithEmailAndPassword(
        email: email, password: password);
    return userCredentials;
  }

 static Future<UserCredential> loginUser({required String email,required String password})async {
    final firebase = FirebaseAuth.instance;
    final userCredential = await firebase.signInWithEmailAndPassword(
        email: email, password: password);
    return userCredential;
  }
}

// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:fluttertoast/fluttertoast.dart';
//
// logIn(email,password)async{
//   try{
//     var firebase = FirebaseAuth.instance;
//     var firebaseLogin =
//     firebase.signInWithEmailAndPassword(email: email, password: password);
//     return firebaseLogin;
//   }
//   catch(e)
//   {
//     if(e.toString().contains('[firebase_auth/invalid-credential]')){
//       Fluttertoast.showToast(msg: 'The supplied auth credential is incorrect malformed or has expired.');
//     }
//     rethrow;
//   }
// }

// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:fluttertoast/fluttertoast.dart';
//
// registration(email,password) async {
//  try {
//
//   }
//   catch(e){
//    if(e.toString().contains('[firebase_auth/invalid-email]')){
//      Fluttertoast.showToast(msg: 'The email address is badly formatted.');
//    }
//         else if(e.toString().contains('[firebase_auth/weak-password]'))
//       Fluttertoast.showToast(msg: 'Password should be at least 6 characters');
//
//     else if(e.toString().contains('[firebase_auth/email-already-in-use]'))
//       Fluttertoast.showToast(msg: 'The email address is already in use by another account.');
//     rethrow;
//   }
//
//   }
//
