import 'package:flutter/material.dart';

class colors {
  static Color appBarColor = Colors.lightGreen;
  static Color buttonTextColor = const Color(0xffedf6f9);

  static Color black54 = Colors.black54;
  static Color black87 = Colors.black87;
  static Color black26 = Colors.black26;
}

