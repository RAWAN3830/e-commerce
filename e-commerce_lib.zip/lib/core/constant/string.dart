class LoginScree {
  static const title = 'Login Account';
  static const subtitle = 'Place Login with ragisted account';
  static const email = 'Email or Phone Number';
  static const password = 'Password';
  static const signin = 'Sign In';
  static const forgotp = 'Forgot PassWord';
  static const enteremail = 'Enter your mail or phone number';
  static const sendcode = 'Send Code';
  static const newpassword = 'New Password';
}


class CreatAccountString {
  static const title = 'Create Account';
  static const subtitle = 'Start learning with create account';
  static const user = 'Username';
  static const email = 'Email or Phone Number';
  static const password = 'Password';
  static const othermethod = 'Or using other method';
}
