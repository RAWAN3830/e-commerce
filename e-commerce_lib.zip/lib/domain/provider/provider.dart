import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';

import '../../core/services/authentication_service/firebase_auth.dart';


class Auth with ChangeNotifier{
bool isLoading = false;
late UserCredential userCredential;

 Future<void> createUser ({required String email, required String password})async {
   userCredential= await AuthService.createUser(email: email, password: password);
  notifyListeners();
}

Future<void> signInUser({required String email, required String password}) async{
  userCredential = await AuthService.loginUser(email: email, password: password);
  notifyListeners();
}



}
