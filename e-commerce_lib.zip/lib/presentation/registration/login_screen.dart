import 'package:e_commerce/presentation/registration/common_widgets/button.dart';
import 'package:e_commerce/core/constant/string.dart';
import 'package:e_commerce/presentation/registration/common_widgets/textfield.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../core/services/firebase_service/firebase_auth_login.dart';
import '../tabs/home_screen/home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    final ButtonSizebox = height * .02;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            icon: Icon(CupertinoIcons.back),
            onPressed: () {
              Navigator.of(context).pop();
            }),
        toolbarHeight: height * .09,
        backgroundColor: Colors.lightGreen,
        title: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Login Account',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              Text(
                'Login into account',
                style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
              )
            ],
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Stack(children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: height * .03,
                ),
                Text(
                  'Email or Phone Number',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
                textField(
                    prefixIcon: Icon(
                      Icons.email_outlined,
                      size: 25,
                      color: Colors.grey,
                    ),
                    controller: emailController,
                    hinttext: 'Enter Your email or Phone number'),
                SizedBox(
                  height: height * .03,
                ),
                Text(
                  LoginScree.password,
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
                textField(
                    prefixIcon: Icon(
                      CupertinoIcons.lock,
                      size: 25,
                      color: Colors.grey,
                    ),
                    controller: passwordController,
                    hinttext: 'Enter Your password'),
                Container(
                  height: height * 0.04,
                  width: double.infinity,
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        'Forgot Password ?',
                        style: TextStyle(
                            color: Colors.lightGreen,
                            fontWeight: FontWeight.bold,
                            fontSize: 18),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: height * .03,
                ),
                MyButton(
                    onTap: () {
                      logIn(emailController.text, passwordController.text);
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => MyHomePage(),
                      ));
                    },
                    text: 'Login'),
                SizedBox(
                  height: ButtonSizebox - 0.04,
                ),
                GestureDetector(
                  onTap: () {},
                  child: Container(
                    height: height * 0.07,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Center(
                      child: Text(
                        'Or using anothor Method',
                        style: const TextStyle(
                            color: Color(0xffadb5bd), fontSize: 16),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ]),
        ),
      ),
    );
  }
}
