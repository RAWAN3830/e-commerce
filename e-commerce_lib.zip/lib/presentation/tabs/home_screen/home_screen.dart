import 'package:carousel_slider/carousel_slider.dart';
import 'package:e_commerce/domain/api_service/call_api.dart';
import 'package:e_commerce/presentation/tabs/home_screen/first.dart';
import 'package:e_commerce/presentation/tabs/home_screen/second.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../domain/model_class.dart';
import '../../registration/common_widgets/tabbat_title.dart';
import 'bottom_navigation_bar.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int current = 0;
  List<ProductModel> pm = [];

  @override
  void initState() {
    super.initState();
    apiRepo().LoadApiData().then((value) {
      setState(() {
        pm = value;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final _height = MediaQuery.of(context).size.height;
    final _width = MediaQuery.of(context).size.width;
    final tabCircle = _height * 0.02;

    // final provider = Provider.of<ProductProvider>(context,listen: true);
    return DefaultTabController(
      length: 2,
      child: Scaffold(

          appBar: AppBar(
            leading: IconButton(
                icon: Icon(CupertinoIcons.back),
                onPressed: () {
                  Navigator.of(context).pop();
                }),
            backgroundColor: Theme.of(context).colorScheme.inversePrimary,
            title: Text('hello'),
            bottom: TabBar(
              isScrollable: true,
                tabs: [
                   // Tab(icon: Icon(Icons.home ,size: _height * 0.035,)),
                  TabbarTitle(title: 'Title1',imagePath: '', ),
                  TabbarTitle(title: 'Title1',imagePath: '',)



            ]),
          ),
          // bottomNavigationBar: BottomNavigationBar(
          //     items: ),
          body: TabBarView(
            // controller: _tabController,
            children: [
              second(),
              first(),


        // BottomBar()
            ],

          )),

    );
  }
}
